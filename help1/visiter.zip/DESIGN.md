---
name: Nordic Hearth
colors:
  surface: '#fff8f5'
  surface-dim: '#e2d8d2'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fcf2eb'
  surface-container: '#f6ece5'
  surface-container-high: '#f0e6e0'
  surface-container-highest: '#ebe1da'
  on-surface: '#1f1b17'
  on-surface-variant: '#4d453f'
  inverse-surface: '#352f2b'
  inverse-on-surface: '#f9efe8'
  outline: '#7f756e'
  outline-variant: '#d0c4bc'
  surface-tint: '#685c54'
  primary: '#685c54'
  on-primary: '#ffffff'
  primary-container: '#eadacf'
  on-primary-container: '#6a5f56'
  inverse-primary: '#d3c4b9'
  secondary: '#615e5c'
  on-secondary: '#ffffff'
  secondary-container: '#e7e1df'
  on-secondary-container: '#676462'
  tertiary: '#645d58'
  on-tertiary: '#ffffff'
  tertiary-container: '#e5dbd4'
  on-tertiary-container: '#66605a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#f0e0d4'
  primary-fixed-dim: '#d3c4b9'
  on-primary-fixed: '#221a13'
  on-primary-fixed-variant: '#4f453d'
  secondary-fixed: '#e7e1df'
  secondary-fixed-dim: '#cac5c4'
  on-secondary-fixed: '#1d1b1a'
  on-secondary-fixed-variant: '#494645'
  tertiary-fixed: '#eae1da'
  tertiary-fixed-dim: '#cec5be'
  on-tertiary-fixed: '#1f1b17'
  on-tertiary-fixed-variant: '#4b4641'
  background: '#fff8f5'
  on-background: '#1f1b17'
  surface-variant: '#ebe1da'
typography:
  headline-display:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  section-gap: 120px
---

## Brand & Style

The design system is built around a "Cream & Mocha" aesthetic, blending the warmth of a Mediterranean cafe with the structured minimalism of Nordic design. The target audience is the high-end lifestyle consumer who values slow living, artisanal quality, and tactile luxury.

The style is **Premium Minimalism**. It utilizes heavy whitespace to create a "breathable" editorial feel, similar to a high-end fashion or architectural brochure. It avoids traditional "digital" tropes like heavy shadows or vibrant gradients, opting instead for a flat, sophisticated layering of organic tones. The emotional response should be one of calm, comfort, and quiet confidence.

## Colors

This design system uses a curated palette of earth-toned neutrals to establish a high-end atmosphere.

- **Primary (Peach Sand):** Used as the main canvas for the application. It provides a warmer, more sophisticated base than pure white.
- **Secondary (Espresso):** Reserved for high-contrast moments—Hero sections, Footers, and Primary Action Buttons. It anchors the design with a sense of permanence and strength.
- **Tertiary (Light Cream):** Used exclusively for card backgrounds and elevated surface elements to create subtle depth against the Peach Sand background.
- **Neutral (Muted Mocha):** Used for secondary text, borders, and icon strokes to maintain legibility without the harshness of black.

## Typography

The typographic strategy pairs the elegance of a classic serif with the functional clarity of a modern sans-serif.

**Playfair Display** is used for all headlines. It should be typeset with tight letter-spacing in display sizes to emphasize its editorial character. Use "headline-display" for hero statements and section titles.

**Inter** handles all functional and long-form text. Its neutral profile ensures high readability across mobile and desktop. Labels and small navigation items should utilize the uppercase styling defined in "label-md" to provide a rhythmic counterpoint to the serif headlines.

## Layout & Spacing

This design system follows a **Fixed Grid** philosophy for desktop to maintain the "brochure" feel, centering content within a 1280px container. 

- **Vertical Rhythm:** A generous 120px gap between major sections ensures that the high-end photography and typography have room to breathe.
- **Grid:** A 12-column grid is used for desktop. For mobile, this collapses into a single column with 20px side margins.
- **Padding:** Internal card padding should be generous (min 32px) to maintain the premium, airy aesthetic.

## Elevation & Depth

Depth in this design system is achieved through **Tonal Layering** rather than shadows. 

- **Surface Level 0:** Peach Sand (#EADACF) serves as the base.
- **Surface Level 1:** Light Cream (#F5EBE4) is used for cards and floating panels.
- **Contrast Level:** Espresso (#2D2B2A) is used for "Inverted" sections where the background is dark and text is light.

Avoid box-shadows entirely. Instead, use thin, low-contrast borders (1px solid #D9C8BC) to define edges where the tonal difference between surfaces is too subtle. For high-impact interactive elements, a slight scale-up (1.02x) on hover is preferred over shadow increases.

## Shapes

The shape language is defined by extremely generous curves, creating a "soft-modern" look. 

While the system is technically "Rounded", the implementation for primary containers and cards uses `rounded-3xl` (24px) to soften the layout. This high degree of curvature mimics the organic shapes of ceramic mugs and cafe furniture. 

Interactive elements like buttons and input fields should follow this 24px radius to ensure consistency across the UI.

## Components

- **Buttons:** Primary buttons use the Espresso (#2D2B2A) background with Peach Sand (#EADACF) text. They should have a 24px corner radius and a minimum height of 56px for a tactile, premium feel. Secondary buttons are outlined in Espresso.
- **Cards:** Cards use the Light Cream (#F5EBE4) background. They should never have shadows. Corner radius is set to 24px. Use high-quality imagery with consistent warm color grading.
- **Input Fields:** Use a subtle Peach Sand background with a bottom-only border in Espresso for a sophisticated, "stationery" look.
- **Chips/Badges:** Small, pill-shaped elements using a slightly darker tint of the background color with the "label-sm" typography.
- **Lists:** Menu items should use "headline-sm" for item titles and "body-md" for descriptions, separated by generous 24px vertical spacing.
- **Dividers:** Use very faint, thin lines (#D9C8BC) only when absolutely necessary to separate distinct content blocks.